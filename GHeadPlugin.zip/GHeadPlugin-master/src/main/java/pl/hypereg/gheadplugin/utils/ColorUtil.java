package pl.hypereg.gheadplugin.utils;


public class ColorUtil {
    public static String fixColor(final String string) {
        return string.replace(">>", "»").replace("&", "§").replace("<<", "«");
    }
}
