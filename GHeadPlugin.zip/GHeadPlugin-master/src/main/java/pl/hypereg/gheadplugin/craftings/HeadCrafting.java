package pl.hypereg.gheadplugin.craftings;

import org.bukkit.Material;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import pl.hypereg.gheadplugin.Main;
import pl.hypereg.gheadplugin.utils.ColorUtil;

public class HeadCrafting implements Listener {
    private Plugin plugin = Main.getPlugin(Main.class);

    public void headCrafting(){
        // Golden Head
        ItemStack head = new ItemStack(Material.SKULL_ITEM, 1, (byte) 3);
        SkullMeta headMeta = (SkullMeta) head.getItemMeta();
        headMeta.setOwner("LegendaryJulien");
        headMeta.setDisplayName(ColorUtil.fixColor(plugin.getConfig().getString("config.gheadname")));
        head.setItemMeta(headMeta);

        // Recipe
        ShapedRecipe shapeless = new ShapedRecipe(head);
        shapeless.shape("###", "#@#", "###");
        shapeless.setIngredient('#', Material.GOLD_INGOT);
        shapeless.setIngredient('@', Material.SKULL_ITEM, (byte) 3);
        plugin.getServer().addRecipe(shapeless);
    }
}
