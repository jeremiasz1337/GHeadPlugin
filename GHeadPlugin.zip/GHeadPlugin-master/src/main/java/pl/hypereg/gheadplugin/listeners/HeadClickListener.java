package pl.hypereg.gheadplugin.listeners;

import org.bukkit.Material;
import org.bukkit.SkullType;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import pl.hypereg.gheadplugin.Main;
import pl.hypereg.gheadplugin.utils.ColorUtil;

public class HeadClickListener implements Listener {
    private Plugin plugin = Main.getPlugin(Main.class);
    @EventHandler
    public void onClickGHead(PlayerInteractEvent event){
        Player player = event.getPlayer();
        if(e.getCurrentItem() == null){ return; }
            if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK){
                if(player.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase(ColorUtil.fixColor(plugin.getConfig().getString("config.gheadname")))){

                    ItemStack head = new ItemStack(Material.SKULL_ITEM, 1, (byte) SkullType.PLAYER.ordinal());
                    SkullMeta headMeta = (SkullMeta) head.getItemMeta();
                    headMeta.setOwner("LegendaryJulien");
                    headMeta.setDisplayName(ColorUtil.fixColor(plugin.getConfig().getString("config.gheadname")));
                    head.setItemMeta(headMeta);

                    if (player.getInventory().getItemInHand().getAmount() > 1) {
                        player.getInventory().getItemInHand().setAmount(player.getInventory().getItemInHand().getAmount() - 1);
                    } else {
                        player.getInventory().remove(player.getInventory().getItemInHand());
                    }
                    player.updateInventory();


                    if(plugin.getConfig().getBoolean("config.healBoolean")) {
                        PotionEffect potion = new PotionEffect(PotionEffectType.REGENERATION, plugin.getConfig().getInt("config.healTimeInt"), plugin.getConfig().getInt("config.healLevelInt"), true);
                        player.addPotionEffect(potion);
                    }
                    if(plugin.getConfig().getBoolean("config.speedBoolean")) {
                        PotionEffect potion = new PotionEffect(PotionEffectType.SPEED, plugin.getConfig().getInt("config.speedTimeInt"), plugin.getConfig().getInt("config.speedLevelInt"), true);
                        player.addPotionEffect(potion);
                    }
                    if(plugin.getConfig().getBoolean("config.absorptionBoolean")) {
                        PotionEffect potion = new PotionEffect(PotionEffectType.ABSORPTION, plugin.getConfig().getInt("config.absorptionTimeInt"), plugin.getConfig().getInt("config.absorptionLevelInt"), true);
                        player.addPotionEffect(potion);
                    }
                    if(plugin.getConfig().getBoolean("config.gheadMessageBoolean")) {
                        player.sendMessage(ColorUtil.fixColor(plugin.getConfig().getString("config.gheadMessage")));
                    }
                    if(plugin.getConfig().getBoolean("config.eatSoundBoolean")) {
                        player.playSound(player.getLocation(), Sound.EAT,2,1);
                    }

                }
        }
    }

}
