package pl.hypereg.gheadplugin;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import pl.hypereg.gheadplugin.craftings.HeadCrafting;
import pl.hypereg.gheadplugin.listeners.HeadClickListener;

public class Main extends JavaPlugin {
    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(new HeadClickListener(), this);
        HeadCrafting headCrafting = new HeadCrafting();
        FileConfiguration config = this.getConfig();
        System.out.println("[1.0] GHEAD-PLUGIN CREATED BY HYPEREG");
        config.addDefault("config.gheadname", "&eGOLDEN HEAD");
        config.addDefault("config.speedBoolean", true);
        config.addDefault("config.healBoolean", true);
        config.addDefault("config.eatSoundBoolean", true);
        config.addDefault("config.absorptionBoolean", true);
        config.addDefault("config.gheadMessageBoolean", true);
        config.addDefault("config.gheadMessage", "&eNice, you use the GHEAD!");
        config.addDefault("config.speedTimeInt", 3);
        config.addDefault("config.healTimeInt", 3);
        config.addDefault("config.absorptionTimeInt", 3);
        config.addDefault("config.speedLevelInt", 3);
        config.addDefault("config.healLevelInt", 3);
        config.addDefault("config.absorptionLevelInt", 3);
        headCrafting.headCrafting();
        config.options().copyDefaults(true);
        saveConfig();
    }

    @Override
    public void onDisable() {
        System.out.println("[1.0] GHEAD-PLUGIN CREATED BY HYPEREG");
    }
}
