# GHeadPlugin 👑

Simple plugin on golden head like hypixel :)

`config.yml`
``` config:
  gheadname: '&eGolden Head'
  speedBoolean: true
  healBoolean: true
  eatSoundBoolean: true
  absorptionBoolean: true
  gheadMessageBoolean: true
  gheadMessage: '&eNice, you use the GHEAD!'
  speedTimeInt: 1000
  healTimeInt: 1000
  absorptionTimeInt: 1000
  speedLevelInt: 3
  healLevelInt: 3
  absorptionLevelInt: 3
```
